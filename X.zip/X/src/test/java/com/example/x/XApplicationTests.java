package com.example.x;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XApplicationTests {

    @Test
    void contextLoads() {
    }

}
