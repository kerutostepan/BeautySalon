package com.example.x.Controller;

import com.example.x.Model.Appointment;
import com.example.x.Repository.AppointmentRepository;
import com.example.x.Service.AppointmentService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Controller
public class ClientScheduleController {

    @Autowired
    private AppointmentRepository appointmentRepository;

    @Autowired
    private AppointmentService appointmentService;

    @GetMapping("/client/schedule")
    public String viewClientSchedule(HttpSession session, Model model) {
        Long clientId = (Long) session.getAttribute("clientId");
        if (clientId != null) {
            List<Appointment> clientAppointments = appointmentRepository.findByClientId(clientId);
            List<Appointment> sortedAppointments = clientAppointments.stream()
                .sorted(Comparator.comparing(Appointment::getDateTime))
                .collect(Collectors.toList());
            List<String> serviceNames = new ArrayList<>();
            for (Appointment appointment : clientAppointments) {
                String serviceName = appointmentService.getServiceNameForAppointment(appointment);
                serviceNames.add(serviceName);
            }
            if (!serviceNames.isEmpty()) {
                model.addAttribute("serviceNames", serviceNames);
            }
            model.addAttribute("clientAppointments", sortedAppointments);
            return "client_schedule";
        } else {
            return "redirect:/login";
        }
    }

    @PostMapping("/client/schedule/cancel/{id}")
    public String cancelAppointment(@PathVariable Long id) {
        appointmentRepository.deleteById(id);
        return "redirect:/client/schedule";
    }
}
