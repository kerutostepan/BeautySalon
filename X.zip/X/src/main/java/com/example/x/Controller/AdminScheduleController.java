package com.example.x.Controller;

import com.example.x.Model.Appointment;
import com.example.x.Repository.AppointmentRepository;
import com.example.x.Service.AppointmentService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Controller
public class AdminScheduleController {

    @Autowired
    private AppointmentRepository appointmentRepository;

    @Autowired
    private AppointmentService appointmentService;


    @GetMapping("/admin/schedule")
    public String viewSchedule(HttpSession session, Model model) {
        Boolean isAdmin = (Boolean) session.getAttribute("isAdmin");
        if (isAdmin != null && isAdmin) {
            List<Appointment> appointments = appointmentRepository.findAll();
            List<Appointment> sortedAppointments = appointments.stream()
                .sorted(Comparator.comparing(Appointment::getDateTime))
                .collect(Collectors.toList());
            List<String> servicesName = new ArrayList<>();
            for (Appointment appointment : appointments) {
                String serviceNames = appointmentService.getServiceNameForAppointment(appointment);
                servicesName.add(serviceNames);
            }
            if (!servicesName.isEmpty()) {
                model.addAttribute("serviceNames", servicesName);
            }
            model.addAttribute("appointments", sortedAppointments);
            return "admin_schedule";
        } else {
            return "redirect:/login";
        }
    }

    @PostMapping("admin/schedule/delete/{id}")
    public String deleteAppointment(@PathVariable Long id) {
        appointmentRepository.deleteById(id);
        return "redirect:/admin/schedule";
    }
}
